# rappid

Dark, neon scroll-driven landing page. Single `index.html`, no build step.

- WebGL light ribbons (three.js) that morph per section
- GSAP ScrollTrigger pins, smear text, 3D slabs, day scrubber
- Lenis smooth scroll on desktop, native scroll on mobile

## Run locally

Open `index.html` in a browser, or:

```
npx serve .
```

## Deploy

Works as-is on GitHub Pages, Netlify, Vercel or any static host.
